const { parentPort } = require("worker_threads");

const getDifference = (a, b) => {
    let diff = a - b;
    return diff;
};

parentPort.on("message", (msg) => {
    const result = getDifference(msg.a, msg.b);
    parentPort.postMessage(result);
});
