const express = require("express");
const { Worker } = require("worker_threads");

const app = express();
const port = 3000;

const getSum = (a, b) => {
    let sum = a + b;
    return sum;
};

app.get("/main", (req, res) => {
    const result = getSum(100, 200);
    res.send(`function getSum on main thread: ${result}`);
});

app.get("/sub", (req, res) => {
    const subThread = new Worker(__dirname + "/subThread.js");
    subThread.on("message", (result) => {
        res.send(`function getSum on sub thread: ${result}`);
    });
    subThread.postMessage({a:100, b:200});
});

app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`);
});
